/*
 * idlet.java
 *
 * Created on 23 de mayo de 2008, 13:07
 */

package hello;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;


/**
 *
 * @author Administrador
 */
public class Midlet extends MIDlet implements CommandListener {
    private Localizame localizame;
    /** Creates a new instance of Midlet */
    public Midlet() {
    }
    
    private Form helloForm;                     
    private StringItem helloStringItem;
    private Command exitCommand;    
    private Command testCommand;
    
                     

    /** This method initializes UI of the application.                        
     */
    private void initialize() {                      
        // Insert pre-init code here
        getDisplay().setCurrent(get_helloForm());                      
        // Insert post-init code here
    }                     
    
    /** Called by the system to indicate that a command has been invoked on a particular displayable.                      
     * @param command the Command that ws invoked
     * @param displayable the Displayable on which the command was invoked
     */
    public void commandAction(Command command, Displayable displayable) {                    
        // Insert global pre-action code here
        if (displayable == helloForm) {                     
            if (command == exitCommand) {                   
                // Insert pre-action code here
                exitMIDlet();                       
                // Insert post-action code here
            }                      
             if (command == testCommand) {                   
                ejecutaLocalizame();
            }                      
        }                    
        // Insert global post-action code here
}                   
    
    /**
     * This method should return an instance of the display.
     */
    public Display getDisplay() {                         
        return Display.getDisplay(this);
    }                        
    
    /**
     * This method should exit the midlet.
     */
    public void exitMIDlet() {                         
        getDisplay().setCurrent(null);
        destroyApp(true);
        notifyDestroyed();
    }                        
    
    /** This method returns instance for helloForm component and should be called instead of accessing helloForm field directly.                        
     * @return Instance for helloForm component
     */
    public Form get_helloForm() {
        if (helloForm == null) {                      
            // Insert pre-init code here
            helloForm = new Form(null, new Item[] {get_helloStringItem()});                       
            helloForm.addCommand(get_exitCommand());
            helloForm.addCommand(get_testCommand());
            helloForm.setCommandListener(this);                     
            // Insert post-init code here
        }                      
        return helloForm;
    }                    
    
    /** This method returns instance for helloStringItem component and should be called instead of accessing helloStringItem field directly.                        
     * @return Instance for helloStringItem component
     */
    public StringItem get_helloStringItem() {
        if (helloStringItem == null) {                      
            // Insert pre-init code here
            helloStringItem = new StringItem("Hello", "Choose Test");                      
            // Insert post-init code here
        }                      
        return helloStringItem;
    }                    
    
    /** This method returns instance for exitCommand component and should be called instead of accessing exitCommand field directly.                        
     * @return Instance for exitCommand component
     */
    public Command get_exitCommand() {
        if (exitCommand == null) {                      
            // Insert pre-init code here
            exitCommand = new Command("Exit", Command.EXIT, 1);                      
            // Insert post-init code here
        }                      
        return exitCommand;
    } 
    
    public Command get_testCommand() {
        if (testCommand == null) {                      
            // Insert pre-init code here
            testCommand = new Command("Test", Command.SCREEN, 2);                      
            // Insert post-init code here
        }                      
        return testCommand;
    }                    
    
    public void set_string(String text) {
        helloStringItem.setText(text);
    }
      public void ejecutaLocalizame(){
        helloStringItem.setText("Enviando Peticion");
        localizame=new Localizame();  
        String re="";
        localizame.Login("666111111","00000");
        if (localizame.isLogged())
        {
            helloStringItem.setText(localizame.Locate("6660000000"));
            localizame.Logout();
            helloStringItem.setText("Logout");
        }
        else
            helloStringItem.setText("Error de login");
    }
    
    public void startApp() {
        initialize();
    }
    
    public void pauseApp() {
    }
    
    public void destroyApp(boolean unconditional) {
    }
    
}





