/*
 * idlet.java
 *
 * Created on 23 de mayo de 2008, 13:07
 */

package hello;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import java.util.Vector;
import java.util.Enumeration;



/**
 *
 * @author Administrador
 */
public class Midlet extends MIDlet implements CommandListener {
    private SMS20 sms20;
    /** Creates a new instance of Midlet */
    public Midlet() {
    }
    
    private Form helloForm;                     
    private StringItem helloStringItem;
    private Command exitCommand;    
    private Command loggin;
    private Command connect;
    private Command enviaSMS;
    private Command polling;
    private Command autoriza;
    private Command add;
    private Command borrar;
    private Command logout;
    private String transactionID;
    
    
                     

    /** This method initializes UI of the application.                        
     */
    private void initialize() {                      
        // Insert pre-init code here
        getDisplay().setCurrent(get_helloForm());                      
        // Insert post-init code here
    }                     
    
    /** Called by the system to indicate that a command has been invoked on a particular displayable.                      
     * @param command the Command that ws invoked
     * @param displayable the Displayable on which the command was invoked
     */
    public void commandAction(Command command, Displayable displayable) {                    
        // Insert global pre-action code here
        if (displayable == helloForm) {                     
            if (command == exitCommand) {                   
                // Insert pre-action code here
                exitMIDlet();                       
                // Insert post-action code here
            }                      
             if (command == loggin) {                   
                ejecutaLogginSMS20();
            }   
            if (command == connect) {                   
                ejecutaConnectSMS20();
            }   
            if (command == enviaSMS) {                   
                ejecutaEnviaSMSSMS20();
            }   
            if (command == polling) {                   
                ejecutaPollingSMS20();
            }
            if (command == autoriza) {                   
                ejecutaAutorizaSMS20();
            }
            if (command == add) {                   
                ejecutaAddSMS20();
            }
            if (command == borrar) {                   
                ejecutaBorrarSMS20();
            }
            if (command == logout) {                   
                ejecutaLogoutSMS20();
            }
        }                    
        // Insert global post-action code here
}                   
    
    /**
     * This method should return an instance of the display.
     */
    public Display getDisplay() {                         
        return Display.getDisplay(this);
    }                        
    
    /**
     * This method should exit the midlet.
     */
    public void exitMIDlet() {                         
        getDisplay().setCurrent(null);
        destroyApp(true);
        notifyDestroyed();
    }                        
    
    /** This method returns instance for helloForm component and should be called instead of accessing helloForm field directly.                        
     * @return Instance for helloForm component
     */
    public Form get_helloForm() {
        if (helloForm == null) {                      
            helloForm = new Form(null, new Item[] {get_helloStringItem()});                       
            helloForm.addCommand(get_exitCommand());
            helloForm.addCommand(get_loggin());
            helloForm.addCommand(get_connect());
            helloForm.addCommand(get_enviaSMS());
            helloForm.addCommand(get_polling());
            helloForm.addCommand(get_autoriza());
            helloForm.addCommand(get_add());
            helloForm.addCommand(get_borrar());
            helloForm.addCommand(get_logout());
           
            helloForm.setCommandListener(this);                     
        }                      
        return helloForm;
    }                    
    
    /** This method returns instance for helloStringItem component and should be called instead of accessing helloStringItem field directly.                        
     * @return Instance for helloStringItem component
     */
    public StringItem get_helloStringItem() {
        if (helloStringItem == null) {                      
            helloStringItem = new StringItem("Hello", "Choose Option");                      
        }                      
        return helloStringItem;
    }                    
    
    /** This method returns instance for exitCommand component and should be called instead of accessing exitCommand field directly.                        
     * @return Instance for exitCommand component
     */
    public Command get_exitCommand() {
        if (exitCommand == null) {                      
            exitCommand = new Command("Exit", Command.EXIT, 1);                      
        }                      
        return exitCommand;
    } 
    
   
    public Command get_loggin() {
        if (loggin == null) {                      
            loggin = new Command("loggin", Command.SCREEN, 2);                      
        }                      
        return loggin;
    }                    
    public Command get_connect() {
        if (connect == null) {                      
            connect = new Command("connect", Command.SCREEN, 2);                      
        }                      
        return connect;
    }      
    public Command get_enviaSMS() {
        if (enviaSMS == null) {                      
            enviaSMS = new Command("enviaSMS", Command.SCREEN, 2);                      
        }                      
        return enviaSMS;
    }      
         
    public Command get_polling() {
        if (polling == null) {                      
            polling = new Command("polling", Command.SCREEN, 2);                      
        }                      
        return polling;
    }      
    public Command get_add() {
        if (add == null) {                      
            add = new Command("add", Command.SCREEN, 2);                      
        }                      
        return add;
    }  
    public Command get_autoriza() {
        if (autoriza == null) {                      
            autoriza = new Command("autoriza", Command.SCREEN, 2);                      
        }                      
        return autoriza;
    }     
    public Command get_borrar() {
        if (borrar == null) {                      
            borrar = new Command("borrar", Command.SCREEN, 2);                      
        }                      
        return borrar;
    }      
    public Command get_logout() {
        if (logout == null) {                      
            logout = new Command("logout", Command.SCREEN, 2);                      
        }                      
        return logout;
    }      
    
    public void set_string(String text) {
        helloStringItem.setText(text);
    }
              
      public void ejecutaLogginSMS20(){
        
        helloStringItem.setText("Enviando Loggin");
        sms20=new SMS20();  
        String re="";
        re=sms20.Login("6XXXXXXXX","Password");
        helloStringItem.setText("Respuesta Loggin"+re);
        
      }
      
       public void ejecutaConnectSMS20(){
        Vector re;
        String nicks;
        nicks="";
        helloStringItem.setText("Enviando Connect");
        re=sms20.Connect("6XXXXXXXX","MyNickName");
        //Iterate from the list of contacts
        Enumeration e=re.elements();
        while (e.hasMoreElements())
        {
            CSMS20Contact nextContact;
            nextContact=(CSMS20Contact)e.nextElement();
            nicks=nicks+" Id="+nextContact.GetUserID()+" alias="+nextContact.GetAlias();
        }
            
        helloStringItem.setText("Respuesta del connect: "+nicks);
       }
       
       public void ejecutaAutorizaSMS20(){
        String re="";
        helloStringItem.setText("Enviando Autoriza");
        sms20.AuthorizeContact("6YYYYYYYY",transactionID);
        helloStringItem.setText("Respuesta del AuthorizeContact");
       }
       public void ejecutaBorrarSMS20(){
        sms20.DeleteContact("6XXXXXXXX","6YYYYYYYY");
        helloStringItem.setText("Usuario borrado");
       }
       
       public void ejecutaAddSMS20(){
        String re="";
        helloStringItem.setText("Enviando Add ");
        re=sms20.AddContact("616685072","659460945");
        helloStringItem.setText("Respuesta del AddContact: "+re);
       }
       
       public void ejecutaPollingSMS20(){
        String re="";
        helloStringItem.setText("Enviando Polling");
        re=sms20.Polling();
        helloStringItem.setText("Respuesta del Polling: "+re);
        if (sms20.IsNewContact(re)==true)
        {
            transactionID=sms20.GetTransactionIDNewContact(re);
            if (transactionID!="")
            {
                sms20.AuthorizeContact(sms20.GetUserIDNewContact(re),sms20.GetTransactionIDNewContact(re));
                helloStringItem.setText("Respuesta del new contact: Telefono: "+sms20.GetUserIDNewContact(re)+" ID="+transactionID);
            }
            else
                helloStringItem.setText("New contact sin transaction id ");
        }
        if (sms20.IsNewMessage(re)==true)
        {
            helloStringItem.setText("Message:"+sms20.GetMessage(re)+" del telefono: "+sms20.GetUserIDMessage(re));
        }
        if (sms20.IsContactPresence(re)==true)
        {
            Vector vePresence=sms20.GetPresenceList(re);
            Enumeration e=vePresence.elements();
            String presenceList="";
            while (e.hasMoreElements())
            {
                CSMS20Contact nextContact;
                nextContact=(CSMS20Contact)e.nextElement();
                presenceList=presenceList+" Id="+nextContact.GetUserID()+" alias="+nextContact.GetAlias()+" Available="+nextContact.GetPresent();
            }
             helloStringItem.setText("Polling. Lista de presencia: "+presenceList);      
        }
       }
       public void ejecutaEnviaSMSSMS20(){
        String re="";
        helloStringItem.setText("Enviando SMS ");
        sms20.SendMessage("6XXXXXXXX","6YYYYYYYY","Message");
        helloStringItem.setText("Respuesta del sendMessage ");
       }
     
       public void ejecutaLogoutSMS20(){
        String re="";
        helloStringItem.setText("Enviando Logout");
        sms20.Logout();
        helloStringItem.setText("Respuesta del Logout ");
       }
       
    public void startApp() {
        initialize();
    }
    
    public void pauseApp() {
    }
    
    public void destroyApp(boolean unconditional) {
    }
    
}





